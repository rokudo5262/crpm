<?php

# Version 2.3.0
$lang['menu_builder']        = 'Setup Menu';
$lang['main_menu']           = 'Menu Principale';
$lang['setup_menu']          = 'Setup Menu';
$lang['utilities_menu_icon'] = 'Icona';
$lang['active_menu_items']   = 'Oggetti Menu Attivi';
$lang['utilities_menu_save'] = 'Salva Menu';
