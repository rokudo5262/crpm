<?php

# Version 2.3.0
$lang['menu_builder']        = 'メニューをセットアップ';
$lang['main_menu']           = 'メインメニュー';
$lang['setup_menu']          = 'メニューをセットアップする';
$lang['utilities_menu_icon'] = 'アイコン';
$lang['active_menu_items']   = 'メニューアイテムをアクティブする';
$lang['utilities_menu_save'] = 'メニューを保存する';
