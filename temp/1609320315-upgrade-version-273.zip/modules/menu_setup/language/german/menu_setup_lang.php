<?php

# Version 2.3.0
$lang['menu_builder']        = 'Menü Einstellungen';
$lang['main_menu']           = 'Hauptmenü';
$lang['setup_menu']          = 'Einstellungsmenü';
$lang['utilities_menu_icon'] = 'Icon';
$lang['active_menu_items']   = 'Aktive Menüpunkte';
$lang['utilities_menu_save'] = 'Menü speichern';
