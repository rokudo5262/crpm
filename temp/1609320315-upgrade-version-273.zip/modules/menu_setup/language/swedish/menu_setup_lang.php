<?php

# Version 2.3.0
$lang['menu_builder']        = 'Menyinställningar';
$lang['main_menu']           = 'Huvudmeny';
$lang['setup_menu']          = 'Inställnings meny';
$lang['utilities_menu_icon'] = 'Ikon';
$lang['active_menu_items']   = 'Aktiva menyposter';
$lang['utilities_menu_save'] = 'Spara menyn';
