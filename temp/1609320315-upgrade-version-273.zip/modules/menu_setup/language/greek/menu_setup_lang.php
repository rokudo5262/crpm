<?php

# Version 2.3.0
$lang['utilities_menu_icon'] = 'Εικόνα';
$lang['active_menu_items']   = 'Ενεργά στοιχεία του μενού';
$lang['inactive_menu_items'] = 'Ανενεργά στοιχεία του μενού';
$lang['utilities_menu_url']  = 'URL';
$lang['utilities_menu_name'] = 'Όνομα';
$lang['utilities_menu_save'] = 'ΑΠΟΘΗΚΕΥΣΗ μενού';
$lang['menu_builder']        = 'Ρύθμιση μενού';
$lang['main_menu']           = 'Βασικό μενού';
$lang['setup_menu']          = 'Ρύθμισε το μενού';
