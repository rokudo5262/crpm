<?php

# Version 2.3.0
$lang['menu_builder']        = 'Menü Kurulumu';
$lang['main_menu']           = 'Ana Menü';
$lang['setup_menu']          = 'Ayarlar Menüsü';
$lang['utilities_menu_icon'] = 'Simge';
$lang['active_menu_items']   = 'Aktif Menü Öğeleri';
$lang['utilities_menu_save'] = 'Menüyü Kaydet';
