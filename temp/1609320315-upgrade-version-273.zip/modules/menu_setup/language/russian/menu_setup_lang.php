<?php

# Version 2.3.0
$lang['menu_builder']        = 'Настройка меню';
$lang['main_menu']           = 'Главное меню';
$lang['setup_menu']          = 'Меню настроек';
$lang['utilities_menu_icon'] = 'Значок';
$lang['active_menu_items']   = 'Активные пункты меню';
$lang['utilities_menu_save'] = 'Сохранить меню';
