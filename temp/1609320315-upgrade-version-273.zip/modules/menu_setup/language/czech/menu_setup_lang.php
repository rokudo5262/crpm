<?php

# Version 2.3.0
$lang['menu_builder']        = 'Nastavení menu';
$lang['main_menu']           = 'Hlavní menu';
$lang['setup_menu']          = 'Možnosti menu';
$lang['utilities_menu_icon'] = 'Ikona';
$lang['active_menu_items']   = 'Aktivní položky menu';
$lang['utilities_menu_save'] = 'Uložit menu';
