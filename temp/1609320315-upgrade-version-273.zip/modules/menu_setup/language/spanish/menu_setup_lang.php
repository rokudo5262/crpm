<?php

# Version 2.3.0
$lang['menu_builder']        = 'Configuración del menú';
$lang['main_menu']           = 'Menú principal';
$lang['setup_menu']          = 'Menú de configuración';
$lang['utilities_menu_icon'] = 'Icono';
$lang['active_menu_items']   = 'Elementos de menú activos';
$lang['utilities_menu_save'] = 'Guardar menú';
