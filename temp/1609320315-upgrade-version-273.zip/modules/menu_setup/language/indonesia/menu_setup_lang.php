<?php

# Version 2.3.0
$lang['menu_builder']        = 'Pengaturan Menu';
$lang['main_menu']           = 'Menu Utama';
$lang['setup_menu']          = 'Pengaturan Menu';
$lang['utilities_menu_icon'] = 'Ikon';
$lang['active_menu_items']   = 'Item Menu yang Aktif';
$lang['utilities_menu_save'] = 'Save Menu';
