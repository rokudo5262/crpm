<?php

# Version 2.3.0
$lang['menu_builder']        = 'Thiết lập menu';
$lang['main_menu']           = 'Menu chính';
$lang['setup_menu']          = 'Thiết lập menu';
$lang['utilities_menu_icon'] = 'Icon';
$lang['active_menu_items']   = 'Các mục khả dụng trong menu';
$lang['utilities_menu_save'] = 'Lưu lại menu';
