<?php

# Versio 2.3.0
$lang['menu_builder']        = 'Réglage Navigation';
$lang['main_menu']           = 'Menu Général';
$lang['setup_menu']          = 'Menu Paramètres';
$lang['utilities_menu_icon'] = 'Icône';
$lang['active_menu_items']   = 'Rubriques Actives';
$lang['utilities_menu_save'] = 'Enregistrer';
