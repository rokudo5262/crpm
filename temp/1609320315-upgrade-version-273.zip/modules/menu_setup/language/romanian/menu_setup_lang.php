<?php

# Version 2.3.0
$lang['menu_builder']        = 'Setarea meniului';
$lang['main_menu']           = 'Meniu principal';
$lang['setup_menu']          = 'Meniul de configurare';
$lang['utilities_menu_icon'] = 'Icon';
$lang['active_menu_items']   = 'Articole active din meniu';
$lang['utilities_menu_save'] = 'Salvați meniul';
