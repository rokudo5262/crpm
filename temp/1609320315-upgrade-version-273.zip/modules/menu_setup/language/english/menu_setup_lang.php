<?php

# Version 2.3.0
$lang['menu_builder']        = 'Menu Setup';
$lang['main_menu']           = 'Main Menu';
$lang['setup_menu']          = 'Setup Menu';
$lang['utilities_menu_icon'] = 'Icon';
$lang['active_menu_items']   = 'Active Menu Items';
$lang['utilities_menu_save'] = 'Save Menu';
