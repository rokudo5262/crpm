<?php

# Version 2.3.0

$lang['menu_builder']        = 'Configuració del menú';
$lang['main_menu']           = 'Menú principal';
$lang['setup_menu']          = 'Menú de configuració';
$lang['utilities_menu_icon'] = 'Icona';
$lang['utilities_menu_save'] = 'Guardar Menú';
$lang['active_menu_items']   = 'Elements de menú actius';
