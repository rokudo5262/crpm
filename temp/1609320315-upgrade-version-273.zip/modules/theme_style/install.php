<?php

defined('BASEPATH') or exit('No direct script access allowed');

add_option('theme_style', '[]');
add_option('theme_style_custom_admin_area', '');
add_option('theme_style_custom_clients_area', '');
add_option('theme_style_custom_clients_and_admin_area', '');
